package com.cg.rms.dao;

import java.util.ArrayList;

import com.cg.rms.beans.*;
import com.cg.rms.exception.RecruitmentException;

public interface CandidateDAO {

	int addResume(Candidate candidate) throws RecruitmentException;
	int modifyResume(Candidate candidate)throws RecruitmentException;
	Candidate viewResume(int candidateId)throws RecruitmentException;
	ArrayList<Company> searchCompanyQualification(String qualification)throws RecruitmentException;
	ArrayList<Company> searchCompanyPosition(String position)throws RecruitmentException;
	ArrayList<Company> searchCompanyYearOfExperience(int yearsOfExperience)throws RecruitmentException;
	ArrayList<Company> searchCompanyLocation(String location)throws RecruitmentException;
	int applyForJob(int candidateId,int companyId)throws RecruitmentException;

}
